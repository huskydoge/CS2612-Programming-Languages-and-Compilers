# Assignment 0915

1. False. 
2. True.
3. False.
4. True. $r^* = {r^*}^*$, represent the same pattern set.
5. ((0|\[1-9][0-9]*)(.\[0-9\]+)?)|(.\[0-9\]+)

