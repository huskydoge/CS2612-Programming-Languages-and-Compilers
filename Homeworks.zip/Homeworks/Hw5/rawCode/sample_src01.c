int x;
int y;
char z;
char * u;
char v[100];
char (* w)[100];
char * (* r)[100];
