int * g (int);
// int (*g) (int);
